export class Note {
    constructor(
        public content: String = "",
    ) {}
}


